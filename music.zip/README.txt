Pack format: 3
Game version: 1.13.x

This pack is made by ~xwj~ and designed for note blocks. It replaces the samples of note blocks. Some instruments are replaced(e.g. the flute and the xylophone).

For a detailed list of instruments and their ranges, check "Instruments&Ranges.png" in the shame directory where this file is located.